﻿# Documake Deployment Package

This package contains all necessary files to deploy Documake.

## Contents

- app.py - Main application file
- requirements.txt - Python dependencies
- templates/ - HTML templates (including landing page)
- static/ - CSS and JavaScript files
- Deployment scripts (setup_deployment.*, run_production.*)
- Virtual environment setup scripts (setup_venv.*)

## About Documake

Documake is a professional document generation platform designed and developed by CIJE using Cursor AI. It provides comprehensive tools for creating paystubs, managing employee records, and generating transaction histories.

## Deployment Instructions

### 1. Extract this zip file to your deployment location

### 2. Run the deployment configuration script:

**Windows PowerShell:**
`powershell
.\setup_deployment.ps1
`

**Windows Command Prompt:**
`cmd
setup_deployment.bat
`

This will:
- Create a virtual environment
- Install all dependencies
- Set up production configuration

### 3. Configure your environment:

Edit the .env file (created by setup script) and update:
- SECRET_KEY (IMPORTANT: Change to a random secret key)
- HOST (default: 0.0.0.0)
- PORT (default: 8080)
- THREADS (default: 4)

### 4. Launch the production server:

**Windows PowerShell:**
`powershell
.\run_production.ps1
`

**Windows Command Prompt:**
`cmd
run_production.bat
`

**Or using Python directly:**
`ash
python run_production.py
`

### 5. Access the application:

Open your browser and navigate to:
- http://localhost:8080 (or your configured port)

## Important Notes

- The database (paystub.db) will be created automatically on first run
- Make sure to change the SECRET_KEY in .env for security
- The application will be accessible from other machines on your network
- Use a reverse proxy (like nginx) for production deployments with SSL

## System Requirements

- Python 3.8 or higher
- Windows, Linux, or macOS
- Internet connection (for initial package installation)

## Support

For issues or questions, refer to the main project documentation.
